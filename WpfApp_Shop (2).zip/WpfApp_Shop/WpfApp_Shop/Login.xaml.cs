﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp_Shop
{
    /// <summary>
    /// Логика взаимодействия для Login.xaml
    /// </summary>
    public partial class Login : Window, Interface_Login
    {
        public Login()
        {
            InitializeComponent();
            IModel model = new Model();
            Presenter_Login login = new Presenter_Login(model, this);
        }
        public string Email
        {
            set
            {
                BoxEmail_Login.Text = value;
            }
            get
            {
                return BoxEmail_Login.Text;
            }
        }
        public string Password
        {
            set
            {
                BoxPassword_Login.Password = value;
            }
            get
            {
                return BoxPassword_Login.Password;
            }
        }

        public event EventHandler<EventArgs> Butt_login;
        private void Button_Register_Click(object sender, RoutedEventArgs e)
        {
            Butt_login?.Invoke(this, EventArgs.Empty);
        }
    }
}
