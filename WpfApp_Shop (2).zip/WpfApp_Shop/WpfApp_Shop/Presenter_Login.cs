﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace WpfApp_Shop
{
    public class Presenter_Login
    {
        public IModel model;
        public Interface_Login login;
        public Presenter_Login() { }

        public Presenter_Login(IModel _model, Interface_Login _login)
        {
            model = _model;
            login = _login;
            login.Butt_login += Login_Butt_login;
        }
        private void Login_Butt_login(object sender, EventArgs e)
        {
            string email = login.Email;
            string password = login.Password;

            if (model.TryLogin_Person(email, password))
            {
                Window_Shop shop = new Window_Shop();
                shop.Show();
            }
            else
            {
                MessageBox.Show("Не правильный Email или Password");
            }
        }
    }
}
