﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp_Shop
{
    public class Presenter
    {
        public readonly IModel model;
        public readonly IView view;
        public Presenter() { }
        public Presenter(IModel _model, IView v_iew)
        {
            model = _model;
            view = v_iew;
            view.Register_Button += View_Register_Button;
        }
        private void View_Register_Button(object sender, EventArgs e)
        {
            string Email = view.Email;
            string Name = view.Name;
            string Password = view.Password;
            string Repeat_Password = view.Repeat_Password;

            Person person = new Person(Email, Name, Password, Repeat_Password);

            model.AddPerson(person);
        }
    }
}
