﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp_Shop
{
    public interface Interface_Login
    {
        string Email { set; get; }
        string Password { set; get; }

        event EventHandler<EventArgs> Butt_login;
    }
}
