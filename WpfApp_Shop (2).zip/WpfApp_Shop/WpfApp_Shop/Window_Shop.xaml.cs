﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp_Shop
{
    /// <summary>
    /// Логика взаимодействия для Window_Shop.xaml
    /// </summary>
    public partial class Window_Shop : Window
    {
        public Window_Shop()
        {
            InitializeComponent();
        }

        private void Image_MouseLeftButtonDown(object sender, MouseButtonEventArgs e)
        {
            FormPerson formPerson = new FormPerson();
            formPerson.Show();
        }

        private void Image_MouseLeftButtonDown_1(object sender, MouseButtonEventArgs e)
        {

        }

        private void Image_MouseLeftButtonDown_2(object sender, MouseButtonEventArgs e)
        {

        }

        private void Image_MouseLeftButtonDown_3(object sender, MouseButtonEventArgs e)
        {
            My_basket basket = new My_basket();
            basket.Show();
        }

        private void MenButton_Click(object sender, RoutedEventArgs e)
        {
            Men clothes = new Men();
            clothes.Show();
        }

        private void WomenButton_Click(object sender, RoutedEventArgs e)
        {
            Women clothes = new Women();
            clothes.Show();
        }

        private void KidsButton_Click(object sender, RoutedEventArgs e)
        {
            Kids clothes = new Kids();
            clothes.Show();
        }

        private void ShoesButton_Click(object sender, RoutedEventArgs e)
        {
            Shoes shoes = new Shoes();
            shoes.Show();
        }
    }
}
