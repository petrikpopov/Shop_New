﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;

namespace WpfApp_Shop
{
    public class Model : IModel
    {
        public string PathFile = "Person.txt";
        public Model() { }
        public void AddPerson(Person person)
        {
            if (string.IsNullOrEmpty(person.Email))
            {
                MessageBox.Show("Поле Email не может быть пустым!");
                return;
            }
            else if (!IsValidEmail(person.Email) || person.Email.Length <= 11)
            {
                MessageBox.Show("Несовместимый адрес электронной почты, либо слишком короткий. Пожалуйста, используйте адрес @gmail.com!");
                return;
            }
            else if (!RepeatEmail_inData(person.Email))
            {
                MessageBox.Show("Данный Email уже есть, придумайте новый !");
                return;
            }
            else if (!RepeatPassword_inData(person.Password))
            {
                MessageBox.Show("Данный пароль уже есть, придумайте новый !");
                return;
            }
            else if (string.IsNullOrEmpty(person.Name))
            {
                MessageBox.Show("Поле Name не может быть пустым!");
                return;
            }
            else if (person.Name.Length < 3 || person.Name.Length > 20)
            {
                MessageBox.Show("Поле Name слишком длинное или короткое!");
                return;
            }
            else if (person.Password.Length < 5 || person.Password.Length > 25)
            {
                MessageBox.Show("Пароль слишком маленький либо длинный!");
                return;
            }
            else if (string.IsNullOrEmpty(person.Password))
            {
                MessageBox.Show("Поле Password не может быть пустым!");
                return;
            }
            else if (string.IsNullOrEmpty(person.Repeat_Password))
            {
                MessageBox.Show("Поле Repeat Password не может быть пустым!");
                return;
            }
            else if (person.Password != person.Repeat_Password)
            {
                MessageBox.Show("Пароли не соответствуют!");
                return;
            }
            else if (person.Password == person.Email)
            {
                MessageBox.Show("Пароль не может быть такой же как и Email!");
                return;
            }
            else
            {
                MessageBox.Show("Вы успешно зарегестрировались!");

            }

            using (StreamWriter writer = new StreamWriter(PathFile, true))
            {
                writer.WriteLine($"Email:{person.Email}\nName:{person.Name}\nPassword:{person.Password}\nRepeat_Password:{person.Repeat_Password}\n");
                writer.Close();
            }

        }
        public bool IsValidEmail(string email)
        {
            string pattern = @"^[A-Za-z0-9+_.-]+@gmail\.com$";
            Regex regex = new Regex(pattern);
            return regex.IsMatch(email);
        }
        public bool RepeatEmail_inData(string email)
        {
            if (File.Exists(PathFile))
            {
                using (StreamReader read = new StreamReader(PathFile))
                {
                    string line;
                    while ((line = read.ReadLine()) != null)
                    {
                        if (line.StartsWith("Email:"))
                        {
                            string Email = line.Replace("Email:", "").Trim();
                            if (email == Email)
                            {
                                return false;
                            }
                        }
                    }
                }
            }
            return true;
        }
        public bool RepeatPassword_inData(string password)
        {
            if (File.Exists(PathFile))
            {
                using (StreamReader streamReader = new StreamReader(PathFile))
                {
                    string line;
                    while ((line = streamReader.ReadLine()) != null)
                    {
                        if (line.StartsWith("Password:"))
                        {
                            string Password = line.Replace("Password:", "").Trim();
                            if (password == Password)
                            {
                                return false;
                            }
                        }
                    }
                }
            }
            return true;
        }
        public bool TryLogin_Person(string email, string password)
        {
            if (File.Exists(PathFile))
            {
                using (StreamReader reader = new StreamReader(PathFile))
                {

                    string StoredEmail = null;
                    string StoredPassword = null;

                    string lines;

                    while ((lines = reader.ReadLine()) != null)
                    {
                        if (lines.StartsWith("Email:"))
                        {
                            StoredEmail = lines.Replace("Email:", "").Trim();
                        }
                        else if (lines.StartsWith("Password:"))
                        {
                            StoredPassword = lines.Replace("Password:", "").Trim();

                            if (StoredEmail != null && StoredPassword != null)
                            {
                                if (email == StoredEmail && password == StoredPassword)
                                {
                                    return true;
                                }
                            }
                        }
                    }

                }
            }
            return false;
        }
    }
}
