﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp_Shop
{
    public interface IModel
    {
        void AddPerson(Person person);
        bool RepeatPassword_inData(string password);
        bool TryLogin_Person(string email, string password);
    }
}
