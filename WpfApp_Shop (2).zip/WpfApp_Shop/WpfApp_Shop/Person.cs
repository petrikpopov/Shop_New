﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp_Shop
{
    public class Person
    {
        public string Email { get; set; }
        public string Name { get; set; }
        public string Password { get; set; }
        public string Repeat_Password { get; set; }

        public Person() { }
        public Person(string email, string name, string password, string rep_password)
        {
            Email = email;
            Name = name;
            Password = password;
            Repeat_Password = rep_password;
        }
        public override string ToString()
        {
            return $"Email:{Email}\n\"Name:{Name}\nPassword:{Password}\nRepeat_Password:{Repeat_Password}\n";
        }
    }
}
