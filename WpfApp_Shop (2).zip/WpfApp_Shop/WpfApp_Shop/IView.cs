﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp_Shop
{
    public interface IView
    {
        string Email { get; set; }
        string Name { get; set; }
        string Password { get; set; }
        string Repeat_Password { get; set; }

        event EventHandler<EventArgs> Register_Button;
    }
}
