﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApp_Shop
{
    /// <summary>
    /// Логика взаимодействия для Register.xaml
    /// </summary>
    public partial class Register : Window,IView
    {
        public Register()
        {
            InitializeComponent();
            IModel model = new Model();
            Presenter presenter = new Presenter(model, this);
        }
        public string Email
        {
            set
            {
                Box_Email.Text = value;
            }
            get
            {
                return Box_Email.Text;
            }
        }
        public string Name
        {
            set
            {
                Box_Name.Text = value;
            }
            get
            {
                return Box_Name.Text;
            }
        }
        public string Password
        {
            set
            {
                Box_Pass.Password = value;
            }
            get
            {
                return Box_Pass.Password;
            }


        }
        public string Repeat_Password
        {
            set
            {
                BoxRep_Pass.Password = value;
            }
            get
            {
                return BoxRep_Pass.Password;
            }
        }

        public event EventHandler<EventArgs> Register_Button;
        private void Button_Register_Click(object sender, RoutedEventArgs e)
        {
            Register_Button?.Invoke(this, EventArgs.Empty);
        }
    }
}
